function validateForm(event) {
    event.preventDefault();

    // Validate First Name
    const firstNameInput = document.getElementById('firstName');
    const firstNameValue = firstNameInput.value.trim();
    if (!/^[A-Za-z]+$/.test(firstNameValue)) {
        alert('First name should only contain alphabets.');
        firstNameInput.focus();
        return;
    }

    // Validate Last Name
    const lastNameInput = document.getElementById('lastName');
    const lastNameValue = lastNameInput.value.trim();
    if (!/^[A-Za-z]+$/.test(lastNameValue)) {
        alert('Last name should only contain alphabets.');
        lastNameInput.focus();
        return;
    }

    // Validate Age
    const ageInput = document.getElementById('age');
    const ageValue = parseInt(ageInput.value, 10);
    if (isNaN(ageValue) || ageValue < 18 || ageValue > 50) {
        alert('Age should be between 18 and 50.');
        ageInput.focus();
        return;
    }

    // If all validations pass, show a success message
    alert('Registration successful!');
}
