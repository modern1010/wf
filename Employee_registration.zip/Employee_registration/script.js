function validateForm() {
    // Get form values
    var dob = new Date(document.getElementById("dob").value);
    var joiningDate = new Date(document.getElementById("joiningDate").value);
    var salary = document.getElementById("salary").value;
  
    // Validate Date of Birth not greater than Joining Date
    if (dob > joiningDate) {
      alert("Date of Birth cannot be greater than Joining Date.");
      return;
    }
  
    // Validate Salary contains only integers
    if (!/^\d+$/.test(salary)) {
      alert("Salary should only contain numbers.");
      return;
    }
  
    // If all validations pass, show success message
    alert("Employee registered successfully!");
  }
  